{% macro convert_idr(usd) %}
   WITH latest_price AS(
      SELECT {{ Price }}
      FROM {{ source('raw', 'usd_idr')}}
      WHERE Date = (SELECT MAX( {{ Date }}))
   )

   SELECT
      {{ usd }} * Price
   
   FROM 
      latest_price

{% endmacro %}

   -- WITH latest_price AS(
   --    SELECT Price
   --    FROM {{ source('transformed', 'USD_IDR_historical_data')}}
   --    WHERE Date = (SELECT MAX(Date));
   -- )

   -- SELECT
   --    {{ total }} * Price
   
   -- FROM 
   --    latest_price

